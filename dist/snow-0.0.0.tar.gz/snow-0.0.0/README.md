# SNOW

Snow is a mostly standalone (only a few required dependencies: numpy and scipy) characterization tool for trajectories generated during MD simulations