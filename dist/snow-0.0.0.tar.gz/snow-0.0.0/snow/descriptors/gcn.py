def atop_gcn():
    pass

def bridge_gcn():
    pass

def three_hollow_gcn():
    pass

def four_hollow_gcn():
    pass